#include <iostream>
using namespace std;

int main() {

    const int size=10;
    int arry[size]={0};
    int *ptr = arry;
    int val;

    for (int i=0;i<size;i++){
        cout<<"Input value for integer "<<i+1<<": ";
        cin>>val;
        *(ptr+i)=val;
    }

    cout<<endl<<endl;

    for (int i=0;i<size;i++){
        cout<<"Integer values in array at position "<<i<<": "<<*(ptr+i)<<endl;
    }

    return 0;
}
