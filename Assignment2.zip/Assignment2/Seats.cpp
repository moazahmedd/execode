#include <iostream>
using namespace std;

int main()
{
    cout<<"Sentinel value: 999"<<endl<<endl;
    const int rowSize=20;
    const int colSize=40;
    int seats[rowSize][colSize];
    int row,col,count=0;
    float total=0;
    int available=0;

    for(int i=0;i<rowSize;i++){
        for(int j=0;j<colSize;j++){
            seats[i][j]=0;
        }
    }

    cout<<"Please input row #: ";
    cin>>row;
    while(row>20 && row<999) {
        cout<<"Invalid value entered. Please re-input: ";
        cin>>row;
    }

    cout<<"Please input col #: ";
    cin>>col;
    while(col>40 && col<999){
        cout<<"Invalid value entered. Please re-input: ";
        cin>>col;
    }

    while(col<999 && row<999){
        if(seats[row-1][col-1]==0){
            seats[row-1][col-1]=1;
            cout<<"Seat in row "<<row<<" and column "<<col<<" has been booked for you."<<endl;
            total += 7.5;
            count += 1;
            cout<<"Your current total bill: $"<<total<<endl<<endl;
        }
        else{
            cout<<"Seat has already been booked."<<endl;
        }

        cout<<"Please input row #: ";
        cin>>row;
        while(row>20 && row<999){
            cout<<"Invalid value entered. Please re-input: ";
            cin>>row;
        }

        if(row>=999){
            break;
        }

        cout<<"Please input col #: ";
        cin>>col;
        while(col>40 && col<999){
            cout<<"Invalid value entered. Please re-input: ";
            cin>>col;
        }

    }
    cout<<endl;
    cout<<"Number of seats taken: "<<count<<endl;
    cout<<"Your final bil: $"<<total<<endl;

    for(int i=0;i<rowSize;i++){
        for(int j=0;j<colSize;j++){
            if(seats[i][j]==0)
                available=available+1;
        }
    }
    cout<<"Number of seats available: "<<available<<endl;



    return 0;
}
