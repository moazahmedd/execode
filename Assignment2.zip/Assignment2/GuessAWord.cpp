#include <iostream>
#include <ctime>
using namespace std;

int main() {
    const int row=6;
    const int col=9;
    const int emptyCol=8;
    char play='Y';
    string gameArray[row][col]= {{"skeleton","s","k","e","l","e","t","o","n",},
                                 {"absolute","a","b","s","o","l","u","t","e"},
                                 {"accepted","a","c","c","e","p","t","e","d"},
                                 {"accounts","a","c","c","o","u","n","t","s"},
                                 {"accident","a","c","c","i","d","e","n","t"},
                                 {"national","n","a","t","i","o","n","a","l"}};

    while (play=='Y') {
        string emptyArray[emptyCol]={"*","*","*","*","*","*","*","*"};
        srand(time(0));
        int random = rand()%row;
        switch (random) {
            case 0:
                cout << "Hint: framework of human body" << endl;
                break;
            case 1:
                cout << "Grading Type under 20 students usually in BNU" << endl;
                break;
            case 2:
                cout << "Visa card is ________ here" << endl;
                break;
            case 3:
                cout <<"Something involved with debit and credit" << endl;
                break;
            case 4:
                cout << "Reckless driving often causes what?" << endl;
                break;
            case 5:
                cout << "Stands for N in BNU.." << endl;
                break;
            default:
                cout<<"Invalid Input"<<endl;
                break;
        }

        int i = 0;
        string alpha;
        cout << "Hidden word: ";
        for (int j = 0; j < emptyCol; ++j) {
            cout << emptyArray[j] << " ";
        }
        cout << endl;
        int tries = 4;
        cout << endl;
        cout << "TRIES: " << tries << endl;
        int asterisk = 8;
        bool present = false;
        while (tries > 0 && asterisk > 0) {
            int found = 0;
            cout << "Input character: ";
            cin >> alpha;

            if (i > 0) {
                for (int j = 0; j < emptyCol; ++j) {
                    //cout<<j<< " ";
                    if (emptyArray[j] == alpha) {
                        present = true;
                    }
                    while (present && j == emptyCol - 1) {
                        cout << "Character already present... please input another character: ";
                        cin >> alpha;
                        present = false;
                        j = -1;
                    }
                }
            }

            for (int i = random, j = 1; j < col; ++j) {
                if (alpha == gameArray[i][j]) {
                    found = 1;
                    emptyArray[j - 1] = alpha;
                    asterisk = asterisk - 1;
                }
            }
            if (found == 0) {
                tries = tries - 1;
                cout << "Character not found... Tries left: " << tries << endl;
                for (int k = 0; k < emptyCol; ++k) {
                    cout << emptyArray[k] << " ";
                }
                cout << endl;
                if (tries == 0) {
                    char know;
                    cout << "\nGame Over..";
                    cout << "Input Y to know the word: ";
                    cin >> know;
                    know = toupper(know);
                    if (know == 'Y') {
                        for (int h = random, i = 1; i < col; ++i) {
                            cout << gameArray[h][i] << " ";
                        }
                        cout << endl;
                    }
                    cout<<"\nWould u like to play again? Input Y to play again: ";
                    cin >> play;
                    play = toupper(play);
                    cout << "\n------------------------------------------------------------------------" <<endl;

                }

            }

            else {
                cout << "Character found: " << alpha << endl;
                for (int k = 0; k < emptyCol; ++k) {
                    cout << emptyArray[k] << " ";
                }
                cout << endl;
            }

            if (asterisk == 0) {
                cout << "\nWell done! Would u like to play again? Input Y to play again: ";
                cin >> play;
                play = toupper(play);
                cout << "\n------------------------------------------------------------------------" <<endl;

            }
            cout<<endl;
            i++;
        }
    }
    return 0;
}
