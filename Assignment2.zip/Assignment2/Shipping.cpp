#include <iostream>
using namespace std;

int main() {
    const int size =4;
    char shipping[size]={'a','r','t','h'};
    string fullname[size]={"air","rail","truck","hand delivery"};
    float rate[size]={14.95,10.25,8.75,25.99};

    char *ptrShipping = shipping;
    float *ptrRate = rate;

    char charr;
    bool found = false;
    char decision = 'Y';
    while(found!=true && decision=='Y') {
        cout<<"Input method to display rate: ";
        cin>>charr;
        charr = tolower(charr);
        for (int i = 0; i < size; ++i) {
            if (charr == ptrShipping[i]) {
                cout << "Rate for shipping method " << fullname[i] << " is $" << ptrRate[i] << endl;
                found=true;
            }
        }

        if(found == false){
            cout<<"Seems like you entered an incorrect address number, do u want to retry? (Input Y for yes): ";
            cin>>decision;
            decision = toupper(decision);
        }

    }
    return 0;
}
