#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    const int rowSize=4;
    const int colSize=3;
    string course[rowSize][colSize]={{"CS100","Mon","9.30am"}, {"CS101","Mon","12.30pm"}, {"CS110","Tues","10.30am"}, {"CS111","Fri","11am"}};
    string courseName;
    int found=0;

    cout<<"-- COURSE NAME -- "<<endl;
    for (int i = 0; i < rowSize; ++i) {
        cout<<" \t"<<course[i][0]<<endl;
    }
    cout<<endl;

    cout<<"For more details, input course name: ";
    cin>>courseName;

    for (int i = 0; i < rowSize; ++i) {
        if (course[i][0] == courseName){
            cout<<course[i][1]<<"  "<<course[i][2]<<endl;
            found=1;
        }
    }
    if(found!=1){
        cout<<"You have entered an invalid course name";
    }




    return 0;
}
