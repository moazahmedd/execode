#include <iostream>
using namespace std;

int main() {
    const int size=4;
    double funds[size]={0};
    string classes[size]={"Freshman","Sophomore","Junior","Senior"};
    //double total[size]={0};
    int classNo=0;

    for (int i = 0; i < size; ++i) {
        cout<<i+1<<". "<<classes[i]<<"\n";
    }
    cout<<endl;
    bool run=true;
    float amount;
    cout<<"Input class number: ";
    cin>>classNo;
    while(classNo!=999){
            cout<<"Input Contribution amount for "<<classes[classNo-1]<<": ";
            cin>>amount; //funds[classNo-1];
            while(amount<0){
                cout<<"Invalid input. Re-input: ";
                cin>>amount;
            }
            funds[classNo-1] += amount;

        cout<<"Input class number: ";
        cin>>classNo;
        }

    int maxContributor=funds[0];
    string nameOfMax=classes[0];
    for (int i = 0; i < size; ++i) {
        cout<<"Amount collected by "<<classes[i]<<": "<<funds[i]<<endl;
        if(maxContributor<funds[i]){
            nameOfMax=classes[i];
        }
    }
    cout<<"Max contribution is done by "<<nameOfMax<<endl;

    return 0;
}
