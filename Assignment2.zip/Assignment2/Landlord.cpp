#include <iostream>
using namespace std;

int main() {
    const int size =5;
    int address[size]={128,204,601,609,612};
    int rent[size]={500,750,495,800,940};

    int *ptrAddress = address;
    int *ptrRent = rent;

    int num;
    bool found = false;
    char decision = 'Y';
    while(found!=true && decision=='Y') {
        cout<<"Input address number to display rent: ";
        cin>>num;
        for (int i = 0; i < size; ++i) {
            if (num == ptrAddress[i]) {
                cout << "Rent for address number " << ptrAddress[i] << " is $" << ptrRent[i] << endl;
                found=true;
            }
        }

        if(found == false){
            cout<<"Seems like you entered an incorrect address number, do u want to retry? Input Y/N: ";
            cin>>decision;
            decision = toupper(decision);
        }

    }
    return 0;
}
