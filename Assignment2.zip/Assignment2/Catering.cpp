#include <iostream>
using namespace std;

int main() {
    const int size=4;
    float price[size]={14.99,12.50,10.75,9.45};
    int meals;
    float total=0;

    cout<<"Input number of meals desired: ";
    cin>>meals;
    while(meals<0){
        cout<<"Invalid input. Please re-input: ";
        cin>>meals;
    }

    if(meals>0){
        cout<<"Price per meal is $";
    }
    if(meals>0 && meals<=10){
        cout<<price[0]<<endl;
        total=meals*price[0];
    }
    else if(meals>10 && meals<=20){
        cout<<price[1]<<endl;
        total=meals*price[0];
    }
    else if(meals>20 && meals<=39){
        cout<<price[2]<<endl;
        total=meals*price[0];
    }
    else if(meals>=40){
        cout<<price[3]<<endl;
        total=meals*price[0];
    }

    cout<<"Your total bill is $"<<total<<endl;
    return 0;
}
