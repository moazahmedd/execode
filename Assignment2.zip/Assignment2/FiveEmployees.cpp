#include <iostream>
using namespace std;

class Employee{
public:
    Employee(){
        fname = lname = "";
        hourlyPayRate= 0.0;
    }

    Employee(string first, string last, float rate){
        fname = first;
        lname = last;
        rate = hourlyPayRate;
    }

    const string &getFname() const {
        return fname;
    }

    void setFname(const string &fname) {
        Employee::fname = fname;
    }

    const string &getLname() const {
        return lname;
    }

    void setLname(const string &lname) {
        Employee::lname = lname;
    }

    float getHourlyPayRate() const {
        return hourlyPayRate;
    }

    void setHourlyPayRate(float hourlyPayRate) {
        Employee::hourlyPayRate = hourlyPayRate;
    }

    void display(){
        cout<<"First Name: "<<fname<<"\nLast Name: "<<lname<<"\nHourly Pay Rate: $"<<hourlyPayRate<<endl;
    }

private:
    string fname;
    string lname;
    float hourlyPayRate;
};

int main() {
    string firstName;
    string lastName;
    float hourlyRate;
    const int size=5;
    Employee employee[5];
    for (int i = 0; i < size; ++i) {
        cout<<"EMPLOYEE "<<i+1<<endl;
        cout<<"Input first name: ";
        cin>>firstName;
        employee[i].setFname(firstName);

        cout<<"Input last name: ";
        cin>>lastName;
        employee[i].setLname(lastName);

        cout<<"Input hourly pay rate: ";
        cin>>hourlyRate;
        employee[i].setHourlyPayRate(hourlyRate);
        cout<<endl;
    }

    int num;
    cout<<"Input number (1-5) to view data for employee: ";
    cin>>num;

    employee[num-1].display();




    return 0;
}
