#include <iostream>
using namespace std;

int main() {

    string name;
    cout<<"Input your name: ";
    cin>>name;

    for (int i = 0; i < name.length(); ++i) {
            if (i == name.length()-1){ //for last character - no asterisk
                cout<<name[i];
            }
            else{
                cout<<name[i]<<"*";
            }
        }
    return 0;
}
