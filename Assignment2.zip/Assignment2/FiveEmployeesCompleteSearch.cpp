#include <iostream>
using namespace std;

class Employee{
public:
    Employee(){
        fname = lname = "";
        hourlyPayRate= 0.0;
        ID=0;
    }

    Employee(string first, string last, float rate,int id){
        fname = first;
        lname = last;
        rate = hourlyPayRate;
        ID= id;
    }

    const string &getFname() const {
        return fname;
    }

    void setFname(const string &fname) {
        Employee::fname = fname;
    }

    const string &getLname() const {
        return lname;
    }

    void setLname(const string &lname) {
        Employee::lname = lname;
    }

    float getHourlyPayRate() const {
        return hourlyPayRate;
    }

    void setHourlyPayRate(float hourlyPayRate) {
        Employee::hourlyPayRate = hourlyPayRate;
    }

    int getId() const {
        return ID;
    }

    void setId(int id) {
        ID = id;
    }

    void display(){
        cout<<"ID: "<<ID<<"\nFirst Name: "<<fname<<"\nLast Name: "<<lname<<"\nHourly Pay Rate: $"<<hourlyPayRate<<endl;
    }

private:
    string fname;
    string lname;
    float hourlyPayRate;
    int ID;
};

int main() {
    cout<<"Sentinel value for ID: any negative value.\nSentinel value for last name: zzz\nSentinel value for hourly pay rate: any negative value.\n\n";
    string firstName;
    string lastName;
    float hourlyRate;
    int id;
    int num=0;
    const int size=5;
    Employee employee[size];
    for (int i = 0; i < size; ++i) {
        cout<<"EMPLOYEE "<<i+1<<endl;
        cout<<"Input ID number: ";
        cin>>id;
        for (int j = 0; j < size; ++j) {
            while(id==employee[j].getId()){
                cout<<"Duplicate Entry. Please enter unique id: ";
                cin>>id;
                j=0;
            }
        }
        employee[i].setId(id);

        cout<<"Input first name: ";
        cin>>firstName;
        employee[i].setFname(firstName);

        cout<<"Input last name: ";
        cin>>lastName;
        employee[i].setLname(lastName);

        cout<<"Input hourly pay rate: ";
        cin>>hourlyRate;
        employee[i].setHourlyPayRate(hourlyRate);
        cout<<endl;
    }
    cout<<endl;
    int option;
    cout<<"Choose the option to search for an employee \n1. ID \n2. Last Name \n3. Hourly Pay\nInput here: ";
    cin>>option;

    cout<<endl;
    if(option==1){
        cout<<"Input ID to view data for employee: ";
        cin>>num;
        while(num>=0){
            int found=0;
            for (int i = 0; i < size; ++i) {
                if(employee[i].getId()==num){
                    employee[i].display();
                    found=1;
                }
                cout<<endl;
            }
            if (found==0){
                cout<<"There is no Employee with a matching ID number"<<endl;
            }
            cout<<endl;
        }
    }

    else if(option==2){
        string lnamee;
        cout<<"Input last name to view data for employee: ";
        cin>>lnamee;
        while(lnamee!="zzz"){
            int found=0;
            for (int i = 0; i < size; ++i) {
                if(employee[i].getLname()==lnamee){
                    employee[i].display();
                    found=1;
                }
                cout<<endl;
            }
            if (found==0){
                cout<<"There is no Employee with a matching last name"<<endl;
            }
            cout<<endl;
        }
    }

    else if(option==3){
        float pay;
        cout<<"Input hourly pay to view data for employee: ";
        cin>>pay;
        while(pay>=0){
            int found=0;
            for (int i = 0; i < size; ++i) {
                if(employee[i].getHourlyPayRate()==pay){
                    employee[i].display();
                    found=1;
                }
                cout<<endl;
            }
            if (found==0){
                cout<<"There is no Employee with a matching hourly pay rate"<<endl;
            }
            cout<<endl;
        }
    }

    else{
        cout<<"Invalid option selected."<<endl;
    }







    return 0;
}
