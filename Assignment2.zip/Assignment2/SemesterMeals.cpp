#include <iostream>
using namespace std;

int main() {
    int rates[4]={300,450,520,590};
    int meals=-1;
    cout<<"How many meals would u like per day? \nInput: ";
    cin>>meals;
    while(meals<0 || meals>3){
        cout<<"Invalid Input. Please re-input: ";
        cin>>meals;
    }

    for (int i = 0; i < 4; ++i) {
        if(meals==i){
            cout<<"Semester rate with the number of meals of your choice per day i.e. "<<meals<<" will be: $"<<rates[i];
        }
    }

    return 0;
}
