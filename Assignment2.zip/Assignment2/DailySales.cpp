#include <iostream>
using namespace std;

int main() {
    int const size=7;
    float sales[size]={0};
    string days[size]={"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"};

    for (int i = 0; i < size; ++i) {
        cout<<"Input store sales for "<<days[i]<<": ";
        cin>>sales[i];
        while (sales[i]<0){
            cout<<"Invalid value entered. Re-input: ";
            cin>>sales[i];
        }
    }
    cout<<endl;
    float max=sales[0];
    float min=sales[0];

    for (int i = 0; i < size; ++i) {
        cout<<"Sales for "<<days[i]<<" is: $"<<sales[i]<<endl;
        if(max<=sales[i]){
            max=sales[i];
        }
        if(min>=sales[i]){
            min=sales[i];
        }
    }

    cout<<endl;
    cout<<"Maximum sale: $"<<max<<endl;
    cout<<"Minimum sale: $"<<min<<endl;





    return 0;
}
