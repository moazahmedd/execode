#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

int main() {
    const int size=4;
    int prices[size]={1500,1700,800,2000};
    string type[size]={"oak", "cherry", "pine", "mahogany"};
    int count[size]={0};
    char decision = 'Y';
    char initial;
    int found =0;

    cout<<"  Wood Type"<<"\t  Initial"<<"\tPrices"<<endl;
    for (int i = 0; i < size; ++i) {
        cout<<setw(8)<<type[i]<<setw(10)<<type[i].at(0)<<setw(10)<<prices[i]<<endl;
    }
    cout<<endl;
    cout<<"Enter initial letter of the Wood type: ";
    cin>>initial;
    while(initial != 'z'){
        for (int i = 0; i < size; ++i) {
            if(type[i].at(0) == initial){
                cout<<type[i]<<" wood's order has been placed."<<endl;
                count[i] += 1;
                found=1;
            }
        }
        if(found != 1){
            cout<<"Invalid wood type!"<<endl;
        }
        found = 0;
        cout<<"\nPlease enter another initial letter of the wood type: ";
        cin>>initial;
        initial= tolower(initial);
    }
    int total=0;
    cout<<endl;
    for (int i = 0; i < size; ++i) {
        if(count[i] != 0){
            cout<<"Number of time order placed for "<<type[i]<<" is: "<<count[i]<<endl;
        }
        total = total + (count[i]*prices[i]);
    }
    if(total!=0)
        cout<<"Total order price: $o"<<total<<endl;


    return 0;
}
