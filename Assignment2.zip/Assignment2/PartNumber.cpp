#include <iostream>
using namespace std;

int main() {

    string partNum;
    cout<<"Enter a PART NUMBER to order: ";
    cin>>partNum;
    string status = "invalid";

    if (partNum[0]=='A'|partNum[0]=='B'|partNum[0]=='C'){
        if (partNum[1]>'0' && partNum[1]<='4' && partNum[2]>='0' && partNum[2]<='9'){
            if (partNum[3]>='a' && partNum[3]<='z'){
                if (partNum[4]>'1' && partNum[4]<='6' && partNum[5]>='0' && partNum[5]<='6'){
                    if (partNum[4]=='2' && partNum[5]<'2'){
                        status="invalid";
                    }
                    else
                        status="valid";
                }
            }
        }
    }

    cout<<"Number entered is "<<status<<endl;

    return 0;
}
