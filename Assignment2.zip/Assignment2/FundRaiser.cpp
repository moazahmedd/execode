#include <iostream>
using namespace std;

int main() {
    const int size=4;
    float funds[size]={0};
    float total=0;
    float avg=0;

    string classes[size]={"Freshman","Sophomore","Junior","Senior"};
    for (int i = 0; i < size ; ++i) {
        cout<<"Input contribution amount by "<<classes[i]<<": ";
        cin>>funds[i];
        while(funds[i]<0){
            cout<<"Invalid input. Re-input: ";
            cin>>funds[i];
        }
        total=total+funds[i];
    }

    avg=total/size;

    cout<<endl;
    for (int i = 0; i < size; ++i) {
        cout<<"Amount collected by "<<classes[i]<<": "<<funds[i]<<endl;
    }
    cout<<endl;
    cout<<"Total amount collected: "<<total<<endl;
    cout<<"Average of the total amount: "<<avg<<endl;

    return 0;
}
