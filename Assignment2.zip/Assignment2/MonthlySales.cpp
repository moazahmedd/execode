#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    int const size=12;
    float sales[size]={0};
    string month[size]={"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
    float total;

    for (int i = 0; i <size ; ++i) {
        cout<<"Input store sales for "<<month[i]<<": ";
        cin>>sales[i];
        while (sales[i]<0){
            cout<<"Invalid value entered. Re-input: ";
            cin>>sales[i];
        }
        total=total+sales[i];
    }
    cout<<endl;
    float avg=total/size;
    cout<<"Annual Average Sale: "<<avg<<endl<<endl;

    for (int i = 0; i < size; ++i) {
        cout<<"Sales for the month of "<<month[i]<<" is "<<sales[i]<<" which compared to annual average sale is ";
        if(sales[i]<avg){
            cout<<"Lower\n";
        }
        else if(sales[i]>avg){
            cout<<"Higher\n";
        }
        else
            cout<<"Equal\n";
    }

    return 0;
}
