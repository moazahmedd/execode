#include <iostream>
using namespace std;

int main() {
    string num;
    string status="incorrectly";
    string newAreaCode;
                          //0123456789012
    cout<<"Example format:  (999)999-9999"<<endl;
    cout<<"Input phone number using above example format: ";
    cin>>num;

    if (num[0] == '('){
        if (num[1]>='0' && num[1]<='9' && num[2]>='0' && num[2]<='9' && num[3]>='0' && num[3]<='9'){
            if(num[4]==')'){
                if(num[5]>='0' && num[5]<='9' && num[6]>='0' && num[6]<='9' && num[7]>='0' && num[7]<='9'){
                    if(num[8]=='-'){
                        if(num[9]>='0' && num[9]<='9' && num[10]>='0' && num[10]<='9' && num[11]>='0' && num[11]<='9' && num[12]>='0' && num[12]<='9'){
                            status = "correctly";
                        }
                    }
                }

            }
        }
    }

    cout<<"Phone number is entered "<<status<<endl;
    cout<<"Phone number without punctuation: ";
    for (int i = 0; i < num.length(); ++i) {
        if (num[i]>='0' && num[i]<='9'){
            cout<<num[i];
        }
    }
    cout<<endl;

    cout<<"Enter new area code: ";
    cin>>newAreaCode;
    cout<<"Updated number with new area code: ";
    for (int i = 0; i < num.length(); ++i) {
        if (i==1 || i==2 || i==3){
            cout<<newAreaCode[i-1];
        }
        else
            cout<<num[i];


    }




    return 0;
}
