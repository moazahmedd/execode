#include <iostream>
using namespace std;

int main() {

    string name;
    cout<<"Input your name: ";
    cin>>name;

    for (int i = name.length(); i >= 0; i--) {
        cout<<name[i];
    }


    return 0;
}
