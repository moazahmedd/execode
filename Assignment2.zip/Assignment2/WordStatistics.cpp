#include <iostream>
using namespace std;

int main() {
    const int size=25;
    char myWord[size]={'\0'};
    int count =0;
    int vowel=0;
    int consonant=0;


    string word;
    cout<<"Input your word: ";
    cin>>word;

    for (int i = 0; i < size; ++i) {
        myWord[i] = word[i];
        if (myWord[i] != '\0'){
            count += 1;  //word.length() could have been used as well after the loop instead of count inside loop.
            if (myWord[i]=='a'||myWord[i]=='e'||myWord[i]=='i'||myWord[i]=='o'||myWord[i]=='u'){
                vowel += 1;
            }
            else{
                consonant +=1;
            }
        }
    }
    cout<<"Total letters in word: "<<count<<"\nNumber of vowels: "<<vowel<<"\nNumber of consonants: "<<consonant<<endl;

    return 0;
}
