#include <iostream>
using namespace std;

class Time{

public:


    Time(){
        hour=min=sec=0;
        term="";
    }

    Time(int h, int m, int s){
        hour=h;
        min=m;
        sec=s;
        check();
        //term="AM";
        //check();
    }

    int getHour(){
        return hour;
    }

    int getMin(){
        return min;
    }

    int getSec(){
        return sec;
    }

    void setHour(int h){
        hour=h;
    }

    void setMin(int m){
        min=m;
    }

    void setSec(int s){
        sec=s;
    }

    void hourCheck(){
        if (hour%12==0){
//            if (hour!=0)
//                cout<<hour;
//            else
            cout<<12;
        }
        else
            cout<<hour%12;
    }

    void display(){
        if (hour%12==0){
//            if (hour!=0)     //keeping in mind case for when hour =24, check sets it to 0.. so hour output will be 0 if this is not done.
//                cout<<hour;
//            else
            cout<<12<<":"<<min<<":"<<sec <<" "<<term;
        }
        else
            cout<<hour%12<<":"<<min<<":"<<sec <<" "<<term;
    }

    void tick(){
        sec = sec + 1;
        check();

    }



private:
    int hour;
    int min;
    int sec;
    string term;

    void check(){

        if(sec>59){
            sec=sec-60;
            min=min+1;
            if(min>59){
                min=min-60;
                hour=hour+1;
                if(hour>23){
                    hour=hour-24;
                }
            }
            else if(hour>23){
                hour=hour-24;
            }

        }
        else if(min>59){
            min=min-60;
            hour=hour+1;
            if(hour>23){
                hour=hour-24;
            }
        }

        else if(hour>23){
            hour=hour-24;
        }

        if(hour<12){
            term="AM";
        }
        else
            term="PM";
    }


//    void displayCheck(){
//        if(hour<12){
//            term="AM";
//        }
//        else
//            term="PM";
//    }

};

int main() {
    Time time(12,0,0);
    time.display();
    cout<<endl;

    int size=86400;

    for (int i = 0; i < size; ++i) {
        time.tick();
        time.display();
        cout<<endl;
    }



    return 0;
}
