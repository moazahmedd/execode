#include <iostream>
using namespace std;

class Orders;
class Items;


class OrderDetails {

private:
    int orderDetailsID;
    Orders *order;
    Items *item;
    int quantity;

public:
    OrderDetails() {
        orderDetailsID = 0;
        order = NULL;
        item = NULL;
    }

    OrderDetails(int id, Orders *orderID, Items *itemID, int quantity) {
        orderDetailsID = id;
        this->quantity = quantity;
        this->order = orderID;
        this->item = itemID;
    }

    void display() {
        cout << "Order Detail ID: " << orderDetailsID
             << ", Quantity: " << quantity <<
             endl << endl;
    }

    int getOrderDetailsId() const { return orderDetailsID; }

    void setOrderDetailsId(int orderDetailsId) {
        orderDetailsID = orderDetailsId;
    }

    Orders *getOrderId() const { return order; }

    void setOrderId(Orders *orderId) { order = orderId; }

    Items *getItemId() const { return item; }

    void setItemId(Items *itemId) { item = itemId; }

    int getQuantity() const { return quantity; }

    void setQuantity(int quantity) { OrderDetails::quantity = quantity; }
};


class Items {
private:
    int itemID;
    string name;
    float price;
    string description;
    string type;
    int size;
    OrderDetails **orderDetails;

public:
    Items() {
        itemID = 0;
        name = description = type = "";
        price = 0.0;
        size = 5; // 20;
        orderDetails = new OrderDetails*[size];
        init();
    }

    Items(int id, string n, float p, string d, string t) {
        itemID = id;
        name = n;
        price = p;
        description = d;
        size = 5; // 20;
        type = t;
        orderDetails = new OrderDetails *[size];
        init();
    }

    void init() {
        for (int i = 0; i < size; ++i) {
            orderDetails[i] = new OrderDetails();
        }
    }

    void display() {
        cout << "\nItem ID: " << itemID << ", Name: " << name
             << ", Description: " << description << ", Price: " << price
             << ", Type: " << type << endl;
        cout << endl << endl;
        for (int i = 0; i < size; ++i) {
            cout << (i + 1) << ".  ";
            orderDetails[i]->display();
        }
    }

    int getItemId() const { return itemID; }

    void setItemId(int itemId) { itemID = itemId; }

    const string &getName() const { return name; }

    void setName(const string &name) { Items::name = name; }

    float getPrice() const { return price; }

    void setPrice(float price) { Items::price = price; }

    const string &getDescription() const { return description; }

    void setDescription(const string &description) {
        Items::description = description;
    }

    const string &getType() const { return type; }

    void setType(const string &type) { Items::type = type; }

    int getSize() const { return size; }

    void setSize(int size) { Items::size = size; }

    const OrderDetails &getOrderDetails() const { return **orderDetails; }

    void setOrderDetails(OrderDetails **orderDetails) {
        Items::orderDetails = orderDetails;
    }
};

class Orders {
private:
    int orderID;
    string description;
    string username;
    OrderDetails **orderDetails;
    int size;

public:
    Orders() {
        orderID = 0;
        description = "";
        size = 5;
        orderDetails = new OrderDetails *[size];
        init();
    }

    Orders(int id,string d) {
        orderID = id;
        description = d;
        size = 5;
        orderDetails = new OrderDetails *[size];
        init();
    }

    void init() {
        for (int i = 0; i < size; ++i) {
            orderDetails[i] = new OrderDetails();
        }
    }
};


int main() {
    //        int itemOneOrderDetailID[]={1000,1001,1002,1003,1004};
    //        float itemOnePrice[]={100,200,300,400,500};
    //
    //        int orderOneOrderID[]={2001,2002,2003,2004,2005};




    return 0;
}
