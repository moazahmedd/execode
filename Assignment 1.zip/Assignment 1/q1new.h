//
// Created by Moaz Ahmed on 17/11/2020.
//

#ifndef Q11_CPP_Q1NEW_H
#define Q11_CPP_Q1NEW_H


class q1new {

};


#endif //Q11_CPP_Q1NEW_H
