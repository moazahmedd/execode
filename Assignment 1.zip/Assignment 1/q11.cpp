#include <iostream>
using namespace std;

class TicTacToe{
private:
    char board[3][3];
    string winner;
    string status;

public:
    TicTacToe(){
        displayModel();
        init();
        status="draw";
        winner="";
        display();
        play();
    }

    void play(){
        int i=1;
        char sign= '2';
        searchWinner(sign);
        while (i<10){
            (sign=='1')? sign='2':sign='1';
            takeInput(sign);
            display();
            i++;
            searchWinner(sign);
            if(winner != ""){
                displayWinner();
                break;
            }
        }
        if(status == "draw"){
            displayWinner();
        }

    }

    void searchWinner(char sign){
        for ( int i = 0; i < 3; ++i ){
            if ((board[i][0] != '0') && (board[i][0] == board[i][1]) && (board[i][0] == board[i][2])){
                status ="win";
                winner= sign;
            }
        }

        for ( int i = 0; i < 3; ++i ){
            if ((board[0][i] != '0') && (board[0][i] == board[1][i]) && (board[0][i] == board[2][i])){
                status ="win";
                winner= sign;
            }
        }

        if ((board[0][0] != '0') && (board[0][0] == board[1][1]) && (board[0][0] == board[2][2])){
            status ="win";
            winner= sign;
        }
        else if ((board[2][0] != '0') && (board[2][0] == board[1][1]) && (board[2][0] == board[0][2])){
            status ="win";
            winner= sign;
        }
    }

    void takeInput(char letter){
        int r,c;
        displayTurn(letter);
        cout<<"Input row num: "; cin>>r;
        r=validate(r);
        cout<<"Input col num: "; cin>>c;
        c=validate(c);
        if(board[r-1][c-1]=='0'){
            board[r-1][c-1] = letter;
        }
        else{
            cout<<"Spot is already taken..."<<endl;
            takeInput(letter);
        }
    }

    int validate(int x){
        int flag;
        if(x>0 && x<4){
            return x;
        }
        else{
            while(!(x>0 && x<4)){
                displayInvalidVal();
                cin>>x;
            }
            return x;
        }
    }

    void init(){
        cout<<"Initializing it.."<<endl;
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 3; ++j) {
                board[i][j]='0';
            }
        }
    }

    void displayModel(){
        cout<<"Please get adjusted with row and column numbers.. displaying sample model"<<endl;
        cout<<"\t    1\t       2\t      3"<<endl;
        cout<<"  ----------------------------------"<<endl;
        for (int i = 0; i <3; ++i) {
            cout<<i+1<<" |";
            for (int j = 0; j <3; ++j) {
                cout<<"     *    |";
            }
            cout<<endl;
            cout<<"  ----------------------------------"<<endl;
        }
        cout<<endl;
    }

    void display(){
        cout<<endl;
        cout<<"\t    1\t       2\t      3"<<endl;
        cout<<"  ----------------------------------"<<endl;
        for (int i = 0; i <3; ++i) {
            cout<<i+1<<" |";
            for (int j = 0; j <3; ++j) {
                cout<<"     "<<board[i][j]<<"    |";
            }
            cout<<endl;
            cout<<"  ----------------------------------"<<endl;

        }
    }

    void displayInvalidVal(){
        cout<<"Invalid value entered...enter correct value: ";
    }

    void displayWinner(){
        if(status=="draw"){
            cout<<"Match is a draw" <<endl;
        }
        else if (winner=="1"){
            cout<<"Winner is player 1";
        }
        else if (winner=="2"){
            cout<<"Winner is player 2";

        }
    }

    void displayTurn(char letter){
        letter=='1' ? cout<<endl<<"Player 1's Turn.."<<endl:cout<<endl<<"Player 2's Turn.."<<endl;
    }

};

int main(){
    TicTacToe tictactoe;
    return 0;
}