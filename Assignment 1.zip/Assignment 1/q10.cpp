#include <iostream>
#include <string>
using namespace std;

class HugeInteger{
public:

    HugeInteger(){
        size = 40;
        ptr = new int[size];
        init();
    }

    HugeInteger(string str){
        size = 40;
        ptr = new int[size];
        init();
        input(str);
    }

    void init(){
        for (int i = 0; i < 40; ++i) {
            ptr[i]=0;
        }
    }

    void input(string str){
        int s = str.length();
        int index=size-s;
        for (int i = index,j=0; i<size ; ++i,++j) {
            ptr[i]=str[j]-48;   //48 means 0 in 'ASCII' code
        }
    }

    void output(){
        int i;
        for ( i = 0; ( ptr[i] == 0 &&  i<size ); i++ )
            cout<<"";
        if ( i == 40 )
            cout << 0;
        else
            for ( i=i; i<size; i++ )
                cout << ptr[i];


//        for (int i = 0; i <size; ++i) {
//            cout<<ptr[i];
//        }
    }

    HugeInteger add(HugeInteger h){
        HugeInteger result;
        int carry=0;
        for (int i = size-1; i >0; i--) {
            result.ptr[i]=ptr[i]+ h.ptr[i] +carry;
            if(result.ptr[i]>9){
                result.ptr[i]=result.ptr[i]%10;
                carry=1;
            }
            else
                carry=0;
        }
        return result;
    }

    HugeInteger subt(HugeInteger h){
        HugeInteger result;
        for (int i = size-1; i >0 ; i--) {
            if(h.ptr[i]>ptr[i]){
                ptr[i-1]=ptr[i-1]-1;
                ptr[i]=ptr[i]+10;
            }
            result.ptr[i] = ptr[i]-h.ptr[i];
        }
        return result;
    }

    bool isEqualTo(HugeInteger h){
//        if(ptr == h.ptr){
//            return true;
//        }
//        else
//            return false;
//
        bool val = (ptr == h.ptr) ? true:false;
        return val;


    }

    bool isNotEqualTo(HugeInteger h){
        bool val = (ptr != h.ptr) ? true:false;
        return val;
    }

    bool isGreaterThan(HugeInteger h){
        bool val = (ptr < h.ptr) ? true:false;
        return val;
    }

    bool isLesserThan(HugeInteger h){
        bool val = (ptr > h.ptr) ? true:false;
        return val;
    }

    bool isLesserThanOrEqualTo(HugeInteger h){
        bool val = (ptr >= h.ptr) ? true:false;
        return val;
    }

    bool isGreaterThanOrEqualTo(HugeInteger h){
        bool val = (ptr <= h.ptr) ? true:false;
        return val;
    }

    bool isZero(){;
        bool val = ptr!=0 ? true:false;
        return val ;
    }




private:
    int size;
    int *ptr;
};

int main(){
    cout<<"HugeInteger 0: ";
    HugeInteger huge_integer0;
    huge_integer0.output();
    cout<<endl;

    cout<<"HugeInteger 1: ";
    HugeInteger huge_integer1("50000300004");
    huge_integer1.output();
    cout<<endl;

    cout<<"HugeInteger 2: ";
    HugeInteger huge_integer2("30000303202");
    huge_integer2.output();
    cout<<endl;

    cout<<"HugeInteger 3: ";
    HugeInteger huge_integer3("925545");
    huge_integer3.output();
    cout<<endl;

    cout<<"HugeInteger 4: ";
    HugeInteger huge_integer4("925544");
    huge_integer4.output();
    cout<<endl<<endl;


    huge_integer1.output(); cout<<" compared to "; huge_integer1.output(); cout<<" using isEqualto() => ";
    (huge_integer1.isEqualTo(huge_integer1)==true) ?  cout<<"Integers are equal"<<endl : cout<<"Integers are not equal"<<endl;

    huge_integer1.output(); cout<<" compared to "; huge_integer2.output(); cout<<" using isNotEqualto() => ";
    (huge_integer1.isNotEqualTo(huge_integer2)==true)? cout<<"Integers are not equal"<<endl : cout<<"Integers are equal"<<endl;

    huge_integer1.output(); cout<<" compared to "; huge_integer2.output(); cout<<" using isGreaterThan() => ";
    (huge_integer1.isGreaterThan(huge_integer2))==true ? (cout<<"HugeInteger 1 is Greater than Huge Integer 2"<<endl):(cout<<"HugeInteger 2 is Greater than Huge Integer 1"<<endl);

    huge_integer1.output(); cout<<" compared to "; huge_integer2.output(); cout<<" using isLesserThan() => ";
    (huge_integer1.isLesserThan(huge_integer2)==true)? cout<<"HugeInteger 1 is Lesser than Huge Integer 2"<<endl : cout<<"HugeInteger 2 is Lesser than Huge Integer 1"<<endl;

    huge_integer3.output(); cout<<" compared to "; huge_integer4.output(); cout<<" using isGreaterThanOrEqualto() => ";
    (huge_integer3.isGreaterThanOrEqualTo(huge_integer4)==true)? cout<<"HugeInteger 3 is Greater than or Equal to Huge Integer 4"<<endl : cout<<"HugeInteger 4 is Greater than or equal to Huge Integer 3"<<endl;

    huge_integer3.output(); cout<<" compared to "; huge_integer4.output(); cout<<" using isLesserThanOrEqualTo() => ";
    (huge_integer3.isLesserThanOrEqualTo(huge_integer4)==true)? cout<<"HugeInteger 3 is Lesser than or Equal to HugeInteger 4"<<endl : cout<<"HugeInteger 4 is Lesser than or equal to Huge Integer 3"<<endl;

    huge_integer0.output(); cout<<" compared using isZero() => ";
    (huge_integer0.isZero() == true)? cout<< "IS Zero"<<endl : cout<<"IS NOT Zero"<<endl;


    cout<<endl<<endl;
    cout<<"Addition of HugeInteger 2 and 3 -> ";
    HugeInteger huge_integer5;
    huge_integer2.output(); cout<<" + "; huge_integer3.output(); cout << " = ";
    huge_integer5 = huge_integer2.add(huge_integer3);
    huge_integer5.output();
    cout<<endl;

    cout<<"Subtraction of HugeInteger 2 and 3 -> ";
    HugeInteger huge_integer6;
    huge_integer2.output(); cout<<" - "; huge_integer3.output(); cout << " = ";
    huge_integer6 = huge_integer2.subt(huge_integer3);
    huge_integer6.output();



    return 0;
}