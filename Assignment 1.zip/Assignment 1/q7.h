//
// Created by Moaz Ahmed on 12/11/2020.
//

#ifndef Q6_CPP_Q7_H
#define Q6_CPP_Q7_H


class q7 {

};


#endif //Q6_CPP_Q7_H
