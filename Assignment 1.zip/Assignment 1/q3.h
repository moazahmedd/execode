//
// Created by Moaz Ahmed on 10/11/2020.
//

#ifndef ASSIGNMENT_1_Q3_H
#define ASSIGNMENT_1_Q3_H


class q3 {

};


#endif //ASSIGNMENT_1_Q3_H
