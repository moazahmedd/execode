//
// Created by Moaz Ahmed on 10/11/2020.
//

#ifndef ASSIGNMENT_1_Q4_H
#define ASSIGNMENT_1_Q4_H


class q4 {

};


#endif //ASSIGNMENT_1_Q4_H
