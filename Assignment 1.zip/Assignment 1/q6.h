//
// Created by Moaz Ahmed on 11/11/2020.
//

#ifndef ASSIGNMENT_1_Q6_H
#define ASSIGNMENT_1_Q6_H


class q6 {

};


#endif //ASSIGNMENT_1_Q6_H
