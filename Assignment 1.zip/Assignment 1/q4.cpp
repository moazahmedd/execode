#include <iostream>
using namespace std;

class Date{

public:
    Date(){
        date=1;
        month=1;
        year=1990;
    }

    Date(int d, int m, int y){
        setYear(y);
        setMonth(m);
        setDate(d);
    }

    int getDate() const {
        return date;
    }



    int getMonth() const {
        return month;
    }

    void setMonth(int m) {
        if (m>0 && m<13){
            month=m;
        }
        else
            month=1;
    }

    int getYear() const {
        return year;
    }

    void setYear(int y) {
        if (y>1920 && y<2021){
            year=y;
        }
        else
            year=1990;
    }
    void setDate(int d) {
        if(month==2){
            if(d>0 && d<29){
                date=d;
            }
            else{
                date=1;
            }
        }

        if(month==2 && (year%400==0 || (year%4==0 && year%100 != 0))){
            if(d>0 && d<=29){
                date=d;
            }
            else{
                date=1;
            }
        }

        if(month==4 || month==6 || month== 9 || month==11){
            if(d>0 && d<31){
                date=d;
            }
            else{
                date=1;
            }
        }

        if (month==1 ||month==3||month==5||month==7||month==8||month==10||month==12){
            if(d>0 && d<=31){
                date=d;
            }
            else{
                date=1;
            }
        }

    }

    void display(){
        if (date<10){
            cout<<"0"<<date<<"/";
        }
        else
            cout<<date<<"/";

        if (month<10){
            cout<<"0"<<month<<"/";
        }
        else
        cout<<month<<"/";

        cout<<year<<" ";

        //cout<<date<<"/"<<month<<"/"<<year<<" ";
    }

    void nextDay(){
        date++;
        check();
    }



private:
    int date;
    int month;
    int year;

    void check() {
        if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10) {
            if (date > 31) {
                date = 1;
                month++;
            }
        } else if (month == 4 || month == 6 || month == 9 || month == 11) {
            if (date > 30) {
                date = 1;
                month++;
            }
        } else if (month == 2 && (year % 400 == 0 || (year % 4 == 0 && year % 100 != 0))) {
            if (date > 29) {
                date = 1;
                month++;
            }
        } else if (month == 2) {
            if (date > 28) {
                date = 1;
                month++;
            }
        }

        else if (month==12 && date>31){
            month=1;
            date=1;
            year++;
        }

    }
        };

int main() {
    cout<<"Year condition is set by me that year should be between 1920 and 2020"<<endl;
    Date date(1,11,2015);
    date.display();
    cout<<endl;
    for (int i = 0; i < 1000; ++i) {
        date.nextDay();
        date.display();
        cout<<endl;
    }
    return 0;
}
