//
// Created by Moaz Ahmed on 12/11/2020.
//

#ifndef Q6_CPP_Q9_H
#define Q6_CPP_Q9_H


class q9 {

};


#endif //Q6_CPP_Q9_H
