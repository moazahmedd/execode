//
// Created by Moaz Ahmed on 12/11/2020.
//

#ifndef Q6_CPP_Q8_H
#define Q6_CPP_Q8_H


class q8 {

};


#endif //Q6_CPP_Q8_H
