#include<iostream>
#include <iomanip>
using namespace std;

class DateAndTime{
private:
    int hour;
    int min;
    int sec;
    string term;
    int date;
    int month;
    int year;
    int nextDaytrigger;

    void timeCheck() {

        if (sec > 59) {
            sec = sec - 60;
            min = min + 1;
            if (min > 59) {
                min = min - 60;
                hour = hour + 1;
                if (hour > 23) {
                    hour = hour - 24;
                    nextDaytrigger = 1;
                }
            }
//            else if(hour>23){
//                hour=hour-24;
//                nextDaytrigger = 1;
//
//            }
//
//        }
//        else if(min>59){
//            min=min-60;
//            hour=hour+1;
//            if(hour>23){
//                hour=hour-24;
//                nextDaytrigger = 1;
//
//            }
//        }
//
//        else if(hour>23){
//            hour=hour-24;
//            nextDaytrigger = 1;
//        }
        }
            if (hour < 12)
                term = "AM";
            else
                term = "PM";


    }

        void dateCheck() {
            if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10) {
                if (date > 31) {
                    date = 1;
                    month++;
                }
            } else if (month == 4 || month == 6 || month == 9 || month == 11) {
                if (date > 30) {
                    date = 1;
                    month++;
                }
            } else if (month == 2 && (year % 400 == 0 || (year % 4 == 0 && year % 100 != 0))) {
                if (date > 29) {
                    date = 1;
                    month++;
                }
            } else if (month == 2) {
                if (date > 28) {
                    date = 1;
                    month++;
                }
            } else if (month == 12 && date > 31) {
                month = 1;
                date = 1;
                year++;
            }

        }



        public:
        DateAndTime()
        {
            term = "AM";
            hour = min = sec = 0;
            date = month = 1;
            year = 1990;
            nextDaytrigger = 0;
        }

        DateAndTime(int
        h, int
        min, int
        s, int
        d, int
        month, int
        y){
            hour = h;
            this->min = min;
            sec = s;
            timeCheck();

            setYear(y);
            setMonth(month);
            setDate(d);
            dateCheck();

            nextDaytrigger = 0;
        }

        int getHour() const {
            return hour;
        }

        void setHour(int hour) {
            DateAndTime::hour = hour;
        }

        int getMin() const {
            return min;
        }

        void setMin(int min) {
            DateAndTime::min = min;
        }

        int getSec() const {
            return sec;
        }

        void setSec(int sec) {
            DateAndTime::sec = sec;
        }

        const string &getTerm() const {
            return term;
        }

        void setTerm(const string &term) {
            DateAndTime::term = term;
        }

        int getDate() const {
            return date;
        }

        void setDate(int d) {
            if (month == 2) {
                if (d > 0 && d < 29) {
                    date = d;
                } else {
                    date = 1;
                }
            }
            if (month == 2 && (year % 400 == 0 || (year % 4 == 0 && year % 100 != 0))) {
                if (d > 0 && d <= 29) {
                    date = d;
                } else {
                    date = 1;
                }
            }

            if (month == 4 || month == 6 || month == 9 || month == 11) {
                if (d > 0 && d < 31) {
                    date = d;
                } else {
                    date = 1;
                }
            }

            if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) {
                if (d > 0 && d <= 31) {
                    date = d;
                } else {
                    date = 1;
                }
            }
        }

        int getMonth() const {
            return month;
        }

        void setMonth(int m) {
            if (m > 0 && m < 13) {
                month = m;
            } else
                month = 1;
        }

        int getYear() const {
            return year;
        }

        void setYear(int y) {
            if (y > 1920 && y < 2021) {
                year = y;
            } else
                year = 1990;
        }

        void timeDisplay() {
            if (hour % 12 == 0) {
//            if (hour!=0)     //keeping in mind case for when hour =24, check sets it to 0.. so hour output will be 0 if this is not done.
//                cout<<hour;
//            else
                cout << 12 << ":" << min << ":" << sec << " " << term;
            } else
                cout << hour % 12 << ":" << min << ":" << sec << " " << term;
        }

        void dateDisplay() {
            cout << date << "/" << month << "/" << year << " ";
        }

        void standardDisplay() {
            timeDisplay();
            cout << "   ";
            //cout<<setw(10);
            dateDisplay();
        }

        void universalDisplay() {
            cout << getHour() << ":" << getMin() << ":" << getSec() << " ";
            cout << setw(7);
            dateDisplay();
        }

        void timeTick() {
            sec = sec + 1;
            timeCheck();
        }

        void nextDay() {
            date++;
            dateCheck();
        }

        void tick() {
            timeTick();
            if (nextDaytrigger == 1) {
                nextDay();
                nextDaytrigger = 0;
            }
        }


};


int main(){
    DateAndTime date_and_time(23,59,55,31,12,2000);
    date_and_time.universalDisplay();    cout<<endl;
    date_and_time.standardDisplay();    cout<<endl;
    cout<<endl;
    const int size =10;
    for (int i = 0; i <size; ++i) {
        date_and_time.tick();
        date_and_time.universalDisplay();    cout<<endl;
        date_and_time.standardDisplay();    cout<<endl;
        cout<<endl;
    }



    return 0;
}