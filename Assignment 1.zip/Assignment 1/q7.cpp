#include <iostream>
using namespace std;
class Rectangle{
private:
    float width;
    float length;

public:
    Rectangle(){
        width=length=1;
    }

    Rectangle(float l, float w){
        setLength(l);
        setWidth(w);
    }

    float getWidth() const {
        return width;
    }

    void setWidth(float w) {
        if(w>0 && w<=20){
            width= w;
        }
        else
            width = 1;
    }

    float getLength() const {
        return length;
    }

    void setLength(float l) {
        if(l>0 && l<=20){
            length = l;
        }
        else
            length = 1;
    }

    float perimeter(){
        return 2*(length+width);
    }

    float area(){
        return length*width;
    }

    void display(){
        cout<<"\tRECTANGLE\nLength = "<<length<<"\nWidth = "<<width<<"\nArea = "<<area()<<"\nPerimeter = "<<perimeter();

    }

};

int main(){
    Rectangle rectangle1;
    rectangle1.display();
    cout<<endl<<endl;

    Rectangle rectangle2(2,4);
    rectangle2.display();
    cout<<endl<<endl;

    Rectangle rectangle3(23,4);
    rectangle3.display();
    cout<<endl<<endl;


    Rectangle rectangle4(2,40);
    rectangle4.display();
    cout<<endl<<endl;


    Rectangle rectangle5(25,40);
    rectangle5.display();
    cout<<endl<<endl;

    return 0;
}