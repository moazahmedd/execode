//
// Created by Moaz Ahmed on 12/11/2020.
//

#ifndef Q6_CPP_Q11_H
#define Q6_CPP_Q11_H


class q11 {

};


#endif //Q6_CPP_Q11_H
