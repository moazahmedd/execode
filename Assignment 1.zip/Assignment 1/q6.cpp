#include <iostream>
using namespace std;

class Time{

public:


    Time(){
        error_flag=0;
        hour=min=sec=0;
        term="";
    }

    Time(int h, int m, int s){
        error_flag=0;
        setHour(h);
        setMin(m);
        setSec(s);
        check();
        //term="AM";
        //check();
    }

    int getHour(){
        return hour;
    }

    int getMin(){
        return min;
    }

    int getSec(){
        return sec;
    }

    void setHour(int h){
        if(h>=0 && h<24){
            hour=h;
        }
        else{
            hour=0;
            error_flag=1;
        }

    }

    void setMin(int m){
        if(m>=0 && m<60){
            min=m;
        }
        else{
            min=0;
            error_flag=1;

        }
    }

    void setSec(int s){
        if(s>=0 && s<60){
            sec=s;
        }
        else {
            sec = 0;
            error_flag=1;
        }
    }

    void display(){
        if(error_flag==1){
                displayError();
        }
        else{
            cout<<"No error in time..."<<endl;
            if (hour%12==0){
//            if (hour!=0)     //keeping in mind case for when hour =24, check sets it to 0.. so hour output will be 0 if this is not done.
//                cout<<hour;
//            else
                cout<<12<<":"<<min<<":"<<sec <<" "<<term;
            }
            else
                cout<<hour%12<<":"<<min<<":"<<sec <<" "<<term;
        }



    }

    void displayError(){
        cout << "Invalid Time entered...changing wrong values to 0.." << endl;
        if(hour==0) {
            cout << hour << ":" << min << ":" << sec << " ";
        }
        else {
            cout << hour << ":" << min << ":" << sec << " " << term;
        }
    }

    void tick(){
        sec = sec + 1;
        check();

    }

private:
    int hour;
    int min;
    int sec;
    int error_flag;
    string term;

    void check(){

        if(sec>59){
            sec=sec-60;
            min=min+1;
            if(min>59){
                min=min-60;
                hour=hour+1;
                if(hour>23){
                    hour=hour-24;
                }
            }
            else if(hour>23){
                hour=hour-24;
            }

        }
        else if(min>59){
            min=min-60;
            hour=hour+1;
            if(hour>23){
                hour=hour-24;
            }
        }

        else if(hour>23){
            hour=hour-24;
        }

        if(hour<12){
            term="AM";
        }
        else
            term="PM";
    }

};

int main() {
    Time time1(15,30,40);
    time1.display();
    cout<<endl<<endl;


    Time time2(15,30,400);
    time2.display();
    cout<<endl<<endl;


    Time time3(15,300,400);
    time3.display();
    cout<<endl<<endl;


    Time time4(150,30,400);
    time4.display();
    cout<<endl<<endl;


    Time time5(150,300,400);
    time5.display();
    cout<<endl<<endl;
    return 0;
}
