//
// Created by Moaz Ahmed on 10/11/2020.
//

#ifndef ASSIGNMENT_1_Q5_H
#define ASSIGNMENT_1_Q5_H


class q5 {

};


#endif //ASSIGNMENT_1_Q5_H
