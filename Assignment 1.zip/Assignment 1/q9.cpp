#include <iostream>
#include <cmath>
using namespace std;

class Point{
private:
    float x;
    float y;

public:
    Point(){
        x=y=1;
    }

    Point(int x, int y){
        setX(x);
        setY(y);
    }

    float getX() const {
        return x;
    }

    void setX(float x) {
        if(x>=0 && x<=20){
            this->x= x;
        }
        else
            this->x = 1;
    }

    float getY() const {
        return y;
    }

    void setY(float y) {
        if(y>=0 && y<=20){
            this->y= y;
        }
        else
            this->y = 1;
    }




};

class Rectangle{
private:
    float width;
    float length;
    Point p1,p2,p3,p4;
    char fill,boundary;

    float doSquare(float val){
        return val*val;
    }

    void makingLength() {
        if (getDistance1() >= getDistance2()) {
            length = getDistance1();
            width = getDistance2();
        } else {
            length = getDistance2();
            width = getDistance1();
        }
    }

    bool checkingIfSquare(){
        bool isASquare=false;
        if(length==width){
            isASquare = true;
        }
        return isASquare;
    }

public:
    Rectangle(){
        length=width=1;
    }

    Rectangle(float x1,float y1,float x2,float y2,float x3,float y3,float x4,float y4):p1(x1,y1),p2(x2,y2),p3(x3,y3),p4(x4,y4){
        isRectangle();
        setFillCharacter('*');
        setPerimeterCharacter('$');
    }

    int isRectangle(){
        int rectangleFound=0;
        getDistance1();
        getDistance2();
        makingLength();
        if((p1.getX()==p2.getX())&&(p3.getX()==p4.getX())&&(p1.getY()==p4.getY())&&(p2.getY()==p3.getY())){
            rectangleFound=1;
        }

        return rectangleFound;
    }

    float getDistance1(){
        float distance =  sqrt((doSquare(p2.getX()-p1.getX())+(doSquare(p2.getY()-p1.getY()))));
        return distance;
    }

    float getDistance2(){
        float distance =  sqrt((doSquare(p4.getY()-p1.getY()))+(doSquare(p4.getX()-p1.getX())));
        return distance;
    }

    float getWidth() const {
        return width;
    }

    float getLength() const {
        return length;
    }

    float perimeter(){
        return 2*(length+width);
    }

    float area(){
        return length*width;
    }

    void setFillCharacter(char symbol){
        fill=symbol;
    }

    void setPerimeterCharacter(char symbol){
        boundary=symbol;
    }

    void draw(){
        if(getLength()>25){
            length=25;
        }
        if(getWidth()>25){
            width=25;
        }

        for(int i=1;i<=width;i++){
            for (int j = 1; j <=length; ++j) {
                if(i==1 || i==width){
                    cout<<boundary;
                }
                else if((i>1 && (j==1||j==length))){
                    cout<<boundary;
                }
                else
                    cout<<fill;
            }
            cout<<endl;
        }
    }

    void display(){
        if (isRectangle()){
            cout<<"-- RECTANGLE --\nLength = "<<length<<"\nWidth = "<<width<<"\nArea = "<<area()<<"\nPerimeter = "<<perimeter()<<endl;
            draw();
        }
        else{
            cout<<"Not a rectangle.."<<endl;
        }


        if(checkingIfSquare()){
            cout<<"*Fun fact: This rectangle is also a square!*"<<endl;

        }
    }



};

int main(){
    Rectangle rectangle4(0,0,0,20,20,20,20,0); cout<<endl;
    rectangle4.display();
    cout<<endl<<endl;

    Rectangle rectangle(1,19,1,10,8,10,10,5); cout<<endl;
    rectangle.setPerimeterCharacter('#');
    rectangle.setFillCharacter('*');
    rectangle.display();
    cout<<endl<<endl;

    Rectangle rectangle2(10,10,10,20,20,20,20,10); cout<<endl;
    rectangle2.setPerimeterCharacter('+');
    rectangle2.setFillCharacter('*');
    rectangle2.display();
    cout<<endl<<endl;

    Rectangle rectangle1(10,10,10,20,5,20,5,10); cout<<endl;
    rectangle1.setPerimeterCharacter('*');
    rectangle1.setFillCharacter('#');
    rectangle1.display();
    cout<<endl<<endl;

    Rectangle rectangle3(0,0,0,20,20,20,20,0); cout<<endl;
    rectangle3.setPerimeterCharacter('#');
    rectangle3.setFillCharacter('*');
    rectangle3.display();
    cout<<endl<<endl;

    return 0;
}