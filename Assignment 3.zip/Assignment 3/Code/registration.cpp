//
// Created by nouman on 12/2/2020.
//
#include "registration.h"

Registration::Registration(){
        registrationId = 0;
        semester = "";
        description = "";
        course = NULL;
        student  = NULL;
    }
Registration::Registration(int rId,string sem,string de,Course *c,Student *s){
        registrationId = rId;
        semester = sem;
        description = de;
        setCourse(c);
        setStudent(s);
    }
Registration::Registration(int rId,string sem,string de){
    registrationId = rId;
    semester = sem;
    description = de;
    course =NULL;
    student = NULL;
}
//Registration::Registration(int rId,string sem,string de,Course c, Student* s){
//    registrationId = rId;
//    semester = sem;
//    description = de;
//    setCourse(&c);
//    setStudent(s);
//}
    int Registration::getRegistrationId() const {
        return registrationId;
    }

    void Registration::setRegistrationId(int registrationId) {
        this->registrationId = registrationId;
    }

    const string &Registration::getSemester() const {
        return semester;
    }

    void Registration::setSemester(const string &semester) {
        this->semester = semester;
    }

    const string &Registration::getDescription() const {
        return description;
    }

    void Registration::setDescription(const string &description) {
        this->description = description;
    }

    Student *Registration::getStudent() const {
        return student;
    }

    void Registration::setStudent(Student *s) {
        student = new Student();
        student->setName(s->getName());
        student->setAddress(s->getAddress());
        student->setSize(s->getSize());
        student->setStudentId(s->getStudentId());
    }

    Course *Registration::getCourse() const {
        return course;
    }

    void Registration::setCourse(Course *c) {
        course = new Course();
        course->setTitle(c->getTitle());
        course->setSize(c->getSize());
        course->setDescription(c->getDescription());
        course->setCourseId(c->getCourseId());
        course->setCredithours(c->getCredithours());
    }

    void  Registration::display() {
        cout<< "Registration Id: " << registrationId << ", Semester: " << semester
           << ", Description: " << description;
        if(course != NULL)
            cout<<", Course Name: "<<course->getTitle();
        if(student != NULL)
           cout<<", Student Name: "<<student->getName()<<endl;
    }

