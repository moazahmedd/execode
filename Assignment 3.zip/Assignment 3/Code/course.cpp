//
// Created by nouman on 12/2/2020.
//
#include<string.h>
#include "course.h"
#include "registration.h"

Course::Course() {
    this->courseId = 0;
    this->title = "";
    this->credithours = 0;
    this->description = "";
    size = 10;
    countReg = 0;
    registrationList = new Registration *[size];
    init();
}

Course::Course(int courseId, string title, int credithours, const string &description) {
    this->courseId = courseId;
    this->title = title;
    this->credithours = credithours;
    this->description = description;
    size = 10;
    countReg = 0;
    registrationList = new Registration *[size];
    init();
}
void Course::init() {
    for (int i = 0; i < size; ++i) {
        registrationList[i] = new Registration();
    }
}

void Course::setRegistration(Registration r){
    if(countReg < size) {
        registrationList[countReg]->setRegistrationId(r.getRegistrationId());
        registrationList[countReg]->setCourse(r.getCourse());
        registrationList[countReg]->setDescription(r.getDescription());
        registrationList[countReg]->setSemester(r.getSemester());
        registrationList[countReg]->setStudent(r.getStudent());
        countReg++;
    }
    else
        cout<<"Registration Already Full for this Course"<<endl;
}

int Course::getCourseId() {
    return courseId;
}

void Course::setCourseId(int courseId) {
   this->courseId = courseId;
}
 string Course::getTitle() {
    return title;
}

void Course::setTitle(string title) {
    this->title = title;
}

int Course::getCredithours() {
    return credithours;
}

void Course::setCredithours(int credithours) {
    this->credithours = credithours;
}

string Course::getDescription() {
    return description;
}

void Course::setDescription(string description) {
   this->description = description;
}

void Course::display() {
    cout<< "Course Id: " << courseId << ", title: " << title << ", credithours: " << credithours
       << ", description: " << description<<endl;
    displayRegistration();
    cout<<"Number of Students registered: "<<countReg<<endl;
    cout<<endl;
}

void Course::setSize(int size) {
    this->size = size;
}
int Course::getSize() {
    return size;
}


void Course::displayRegistration(){
    for (int i = 0; i < countReg; ++i) {
        registrationList[i]->display();
    }
}
Registration Course::getRegistration(int index){
    return *(registrationList[index]);
}


Registration ** Course::getRegistrationList() { return registrationList; }

void Course::setRegistrationList(Registration **regList) {
    registrationList = regList;
}

