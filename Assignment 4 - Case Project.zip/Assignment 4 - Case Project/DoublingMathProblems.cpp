#include <iostream>
#include <ctime>
#include<stdlib.h>
using namespace std;

class Fraction{
public:
    Fraction(){
        numerator=wholePart=0;
        denominator=1;
    }

    Fraction(int w, int n, int d){
        numerator= n;
        denominator= d;
        wholePart=w;
    }

    void setFraction(int w, int n, int d){ //needed at time of making array in main
        numerator= n;
        denominator= d;
        wholePart=w;
    }

    int getNumerator() const {
        return numerator;
    }

    void setNumerator(int numerator) {
        Fraction::numerator = numerator;
    }

    int getDenominator() const {
        return denominator;
    }

    void setDenominator(int denominator) {
        Fraction::denominator = denominator;
    }

    int getWholePart() const {
        return wholePart;
    }

    void setWholePart(int wholePart) {
        Fraction::wholePart = wholePart;
    }

private:
    int numerator;
    int denominator;
    int wholePart;
};

class MathProblem : public Fraction{
public:
    MathProblem(){
        operand = ' ';
        isAnswerCorrect = 0;
    }

    MathProblem(int op1, int op2, int wholePart):Fraction(op1,op2,wholePart){
        operand = ' ';
        isAnswerCorrect = 0;
    }

    void setProblem(Fraction op1, Fraction op2, char operandd) {
        operand1 = op1;
        operand2 = op2;
        operand = operandd;
        int newNumerator1 = (operand1.getWholePart() * operand1.getDenominator()) + operand1.getNumerator(); //getting numerator -> mixed num to improper fraction 
        int newNumerator2 = (operand2.getWholePart() * operand2.getDenominator()) + operand2.getNumerator(); //getting numerator -> mixed num to improper fraction
        if (operand == '+') {
            correctAnswer.setNumerator((newNumerator1 * operand2.getDenominator()) + (newNumerator2 * operand1.getDenominator()));
           // correctAnswer.setDenominator(operand1.getDenominator() * operand2.getDenominator());
        }
        else if (operand == '-')
        {
            correctAnswer.setNumerator((newNumerator1 * operand2.getDenominator()) - (newNumerator2 * operand1.getDenominator()));
           // correctAnswer.setDenominator(operand1.getDenominator() * operand2.getDenominator());
        }
        else if (operand == '*')
        {
            correctAnswer.setNumerator(operand1.getNumerator()*operand2.getNumerator());
           // correctAnswer.setDenominator(operand1.getDenominator() * operand2.getDenominator());
        }
        else if (operand == '/')
        {
            correctAnswer.setNumerator(operand1.getNumerator()*operand2.getDenominator());
            correctAnswer.setDenominator(operand1.getDenominator() * operand2.getNumerator());
        }
        else{
            cout<<"Invalid operator!"<<endl;
        }

        if(operand != '/'){
            correctAnswer.setDenominator(operand1.getDenominator() * operand2.getDenominator());
        }

        for (int i=2;i<10;i++)
        {   
            if (correctAnswer.getNumerator()%i==0 && correctAnswer.getDenominator()%i==0)
            {
                correctAnswer.setNumerator((correctAnswer.getNumerator())/i);
                correctAnswer.setDenominator((correctAnswer.getDenominator())/i);
                i--;
            }
        }
        


        if(correctAnswer.getNumerator()>=correctAnswer.getDenominator()){   //converting final ans to mixed num.
            correctAnswer.setWholePart(correctAnswer.getNumerator()/correctAnswer.getDenominator());
            correctAnswer.setNumerator(correctAnswer.getNumerator()%correctAnswer.getDenominator());
        }

        

        userAnswer.setNumerator(0);
        userAnswer.setDenominator(1); 
        userAnswer.setWholePart(0);
        isAnswerCorrect = 0;

    }
    void displayProblem(){
        if(operand1.getWholePart()== 0){
            if (operand2.getWholePart()==0){
                cout<<operand1.getNumerator()<<"/"<<operand1.getDenominator()<<" "<<operand<<" "<<operand2.getNumerator()<<"/"<<operand2.getDenominator()<<endl;
            }
            else{
                cout<<operand1.getNumerator()<<"/"<<operand1.getDenominator()<<" "<<operand<<" "<<operand2.getWholePart() <<" "<<operand2.getNumerator()<<"/"<<operand2.getDenominator()<<endl;
            }
        }
        else if(operand2.getWholePart()==0){
            if (operand1.getWholePart()==0){
                cout<<operand1.getNumerator()<<"/"<<operand1.getDenominator()<<" "<<operand<<" "<<operand2.getNumerator()<<"/"<<operand2.getDenominator()<<endl;
            }
            else{
                cout<<operand1.getWholePart() <<" "<<operand1.getNumerator()<<"/"<<operand1.getDenominator()<<" "<<operand<<" "<<operand2.getNumerator()<<"/"<<operand2.getDenominator()<<endl;
            }
        }
        else{
            cout<<operand1.getWholePart() <<" "<<operand1.getNumerator()<<"/"<<operand1.getDenominator()<<" "<<operand<<" "<<operand2.getWholePart() <<" "<<operand2.getNumerator()<<"/"<<operand2.getDenominator()<<endl;
        }
    }

    void askForAnswer(){
        int w,n,d;
        cout<<"Input whole number for solved ans: ";
        cin >> w;
        userAnswer.setWholePart(w);
        
        if(correctAnswer.getNumerator()!=0){  
            cout<<"Input numerator for solved ans: ";
            cin>> n;         
            userAnswer.setNumerator(n);
            cout<<"Input denominator for solved ans: ";
            cin>>d;  
            userAnswer.setDenominator(d);
        }
        else{   //INCASE if final ans is just whole number eg 1 1/2 + 1 1/2 = 3 ..
            userAnswer.setNumerator(0);
            userAnswer.setDenominator(1);
        }
        


        if (userAnswer.getWholePart() == correctAnswer.getWholePart() && userAnswer.getDenominator() == correctAnswer.getDenominator() && userAnswer.getNumerator() == correctAnswer.getNumerator()){
            isAnswerCorrect=1;
        }
    }

    void displayCorrectAns(){
        if(correctAnswer.getNumerator() != 0){
            cout<<"Correct Answer: "<<correctAnswer.getWholePart()<<" "<<correctAnswer.getNumerator()<<"/"<<correctAnswer.getDenominator()<<endl;  
        }
        else{
            cout<<"Correct Answer: "<<correctAnswer.getWholePart()<<endl;
        }
    }

    void displayUserAns(){
        if(userAnswer.getNumerator() != 0){
            cout<<"User Answer: "<<userAnswer.getWholePart()<<" "<<userAnswer.getNumerator()<<"/"<<userAnswer.getDenominator()<<endl;  
        }
        else{
            cout<<"User Answer: "<<userAnswer.getWholePart()<<endl;
        }
    }

    void display(){
        displayCorrectAns();
        displayUserAns();

        if (isAnswerCorrect == 1){
            cout<<"Your answer is correct!"<<endl;
        }
        else{
            cout<<"Your answer is Wrong!"<<endl;
        }
    }

    int getIsAnswerCorrect(){
        return isAnswerCorrect;
    }

    const Fraction &getOperand1() const {
        return operand1;
    }

    void setOperand1(const Fraction &operand1) {
        MathProblem::operand1 = operand1;
    }

    const Fraction &getOperand2() const {
        return operand2;
    }

    void setOperand2(const Fraction &operand2) {
        MathProblem::operand2 = operand2;
    }

    const Fraction &getCorrectAnswer() const {
        return correctAnswer;
    }

    void setCorrectAnswer(const Fraction &correctAnswer) {
        MathProblem::correctAnswer = correctAnswer;
    }

    const Fraction &getUserAnswer() const {
        return userAnswer;
    }

    void setUserAnswer(const Fraction &userAnswer) {
        MathProblem::userAnswer = userAnswer;
    }

    char getOperand() const {
        return operand;
    }

    void setOperand(char operand) {
        MathProblem::operand = operand;
    }

    void setIsAnswerCorrect(int isAnswerCorrect) {
        MathProblem::isAnswerCorrect = isAnswerCorrect;
    }

private:
    Fraction operand1;
    Fraction operand2;
    Fraction correctAnswer;
    Fraction userAnswer;
    char operand;
    int isAnswerCorrect;
};

class DoublingMathProblem : public MathProblem{
public:
  
    void setProblem(Fraction f1){
        operand1 = operand2 = f1;
        int newNumerator1 = (operand1.getWholePart() * operand1.getDenominator()) + operand1.getNumerator();
        int newNumerator2 = (operand2.getWholePart() * operand2.getDenominator()) + operand2.getNumerator();
        correctAnswer.setNumerator((newNumerator1 * operand2.getDenominator()) + (newNumerator2 * operand1.getDenominator()));
        correctAnswer.setDenominator(operand1.getDenominator() * operand2.getDenominator());
        for (int i=2;i<10;i++) //Simplifying the Fraction's correct answer!
        {   
            if (correctAnswer.getNumerator()%i==0 && correctAnswer.getDenominator()%i==0)
            {
                correctAnswer.setNumerator((correctAnswer.getNumerator())/i);
                correctAnswer.setDenominator((correctAnswer.getDenominator())/i);
                i--;
            }
        }
        
        if(correctAnswer.getNumerator()>=correctAnswer.getDenominator()){   //converting final ans to mixed num.
            correctAnswer.setWholePart(correctAnswer.getNumerator()/correctAnswer.getDenominator());
            correctAnswer.setNumerator(correctAnswer.getNumerator()%correctAnswer.getDenominator());
        }
        
        userAnswer.setNumerator(0);
        userAnswer.setDenominator(1); //couldn't decide to keep it 1 or 0.
        userAnswer.setWholePart(0);
        isAnswerCorrect = 0;

        MathProblem::setOperand1(f1);
        MathProblem::setOperand2(f1);
        MathProblem::setCorrectAnswer(correctAnswer);
        MathProblem::setUserAnswer(userAnswer);
        MathProblem::setOperand('+');
        MathProblem::setIsAnswerCorrect(isAnswerCorrect);
        
    }

private:
    Fraction operand1;
    Fraction operand2;
    Fraction correctAnswer;
    Fraction userAnswer;
    int isAnswerCorrect;
};

int main() {
    srand(time(0));
    float score=0;
    // Fraction f1(1,1,2);
    // //Fraction f2(2,2,4);
    // DoublingMathProblem m;
    // m.setProblem(f1);
    // m.displayProblem();
    // m.askForAnswer();
    // m.display();

    Fraction fArray[12];
    fArray[0].setFraction(1,1,2);
    fArray[1].setFraction(1,1,3);
    fArray[2].setFraction(1,1,4);
    fArray[3].setFraction(2,1,2);
    fArray[4].setFraction(2,1,3);
    fArray[5].setFraction(2,1,4);
    fArray[6].setFraction(3,1,3);
    fArray[7].setFraction(3,1,2);
    fArray[8].setFraction(3,1,4);
    fArray[9].setFraction(4,1,2);
    fArray[10].setFraction(4,1,3);
    fArray[11].setFraction(4,1,4);
    DoublingMathProblem dmArray[5];
    int random1;   
    for (int i = 0; i < 5; i++)
    {
        random1 = rand()%12;    
        cout<<"Problem "<<i+1<<" :-"<<endl;
        dmArray[i].setProblem(fArray[random1]);
        dmArray[i].displayProblem();
        dmArray[i].askForAnswer();
        if(dmArray[i].getIsAnswerCorrect()){
            score++;
        }
        cout<<endl;
    }
    for (int i = 0; i < 5; i++)
    {        
        cout<<endl;
        dmArray[i].display();
    }
    cout<<"\nYour final score as percentage: "<<(score/5 * 100)<<"%"<<endl;
    return 0;
}
