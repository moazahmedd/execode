        // for (int i=1;i<10;i++)
        // {   
        //     if (correctAnswer.getNumerator()%i && correctAnswer.getDenominator()%i)
        //     {
        //         correctAnswer.setNumerator(correctAnswer.getNumerator()/i);
        //         correctAnswer.setDenominator(correctAnswer.getDenominator()/i);
        //     }
        // }