//
// Created by Moaz Ahmed on 27/12/2020.
//

#ifndef MAIN_CPP_DOUBLINGMATHPROBLEMS_H
#define MAIN_CPP_DOUBLINGMATHPROBLEMS_H


class DoublingMathProblems {

};


#endif //MAIN_CPP_DOUBLINGMATHPROBLEMS_H
