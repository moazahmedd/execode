package com.library.bl;


import com.library.entity.IssueBooks;
import com.library.ui.IssueBooksUi;
import com.library.ui.LibraryHomeUI;
import com.library.util.ConnectionDB;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class IssueBussinessHandler implements ActionListener {

    Connection theConnectionDB;
    Statement statement;
    ResultSet resultSet;
    IssueBooksUi theGui;
    public IssueBussinessHandler(IssueBooksUi issueBooksUi) {
        try {
            theGui = issueBooksUi;
            theConnectionDB = ConnectionDB.getConnectionDB();
            statement = theConnectionDB.createStatement();
        }
        catch (SQLException s){
            s.printStackTrace();
        }

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getActionCommand().equals("Issue")){
            try {
                JOptionPane.showMessageDialog(null,"Book Issued!");

                IssueBooks issueBooks = new IssueBooks();

                issueBooks.setStudentId(theGui.getTxtStudentId().getText().toString());
                issueBooks.setIssueDate(theGui.getTxtIssueDate().getText().toString());
                issueBooks.setBookId(theGui.getTxtBookId().getText().toString());
                issueBooks.setIssueId(theGui.getTxtIssueId().getText().toString());
                System.out.println(issueBooks);

                String strInsertQuery = "INSERT INTO issuebooks(Issue_id,Book_ID,Student_id,issue_date,return_date)" +
                        "VALUES ('" + issueBooks.getIssueId() + "','"+issueBooks.getBookId()+"','" + issueBooks.getStudentId() + "','" + issueBooks.getIssueDate() + "','" + issueBooks.getIssuedTill() + "');";
                String strUpdateQuery = "UPDATE library.books SET book_quantity  = book_quantity-1 WHERE book_id = '"+issueBooks.getBookId()+"';";

                statement.execute(strInsertQuery);
                statement.execute(strUpdateQuery);
            }catch (SQLException s){
                s.printStackTrace();
            }
        }
        else if(e.getActionCommand().equals("Cancel")){
            theGui.dispose();
        }
    }
}
