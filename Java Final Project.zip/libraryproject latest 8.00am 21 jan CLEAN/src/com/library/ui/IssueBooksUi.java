package com.library.ui;

import com.library.bl.IssueBussinessHandler;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;

public class IssueBooksUi extends JFrame {
    JLabel title;
    JLabel lblIssueId;
    JLabel lblStudentId;
    JLabel lblTotalPeriod;
    JLabel lblBookId;
    JLabel lblIssueDate;
    JButton btnIssue;
    JButton btnCancel;

    JTextField txtStudentId;
    JTextField txtIssueId;
    JTextField txtTotalPeriod;
    JTextField txtIssueDate;
    JTextField txtBookId;

    public IssueBooksUi() throws HeadlessException {
        init();
    }

    public void init(){

        title = new JLabel();
        title.setText("Issue A Book");
        title.setFont(new Font("Times New Roman", Font.ITALIC+Font.BOLD, 23));
        title.setBounds(190,20,300,40);

        lblIssueId = new JLabel();
        lblIssueId.setText("Issue ID : ");
        lblIssueId.setBounds(30,90,120,30);

        txtIssueId = new JTextField();
        txtIssueId.setBounds(180,90,250,30);

        lblBookId = new JLabel();
        lblBookId.setText("Book ID : ");
        lblBookId.setBounds(30,150,120,30);

        txtBookId = new JTextField();
        txtBookId.setBounds(180,150,250,30);

        lblStudentId = new JLabel();
        lblStudentId.setText("Student ID : ");
        lblStudentId.setBounds(30,210,120,30);

        txtStudentId= new JTextField();
        txtStudentId.setBounds(180,210,250,30);

        lblIssueDate = new JLabel();
        lblIssueDate.setText("Issue Date : ");
        lblIssueDate.setBounds(30,270,120,30);

        txtIssueDate = new JTextField();
        txtIssueDate.setBounds(180,270,250,30);

        btnIssue = new JButton();
        btnIssue.setText("Issue");
        btnIssue.setBounds(140,330,100,40);
        btnIssue.setBackground(Color.darkGray);
        btnIssue.setForeground(Color.white);
        btnIssue.setOpaque(true);
        btnIssue.setBorderPainted(false);   //NEEDED ON MAC

        btnCancel = new JButton();
        btnCancel.setText("Cancel");
        btnCancel.setBounds(270,330,100,40);
        btnCancel.setBackground(Color.gray);
        btnCancel.setForeground(Color.white);
        btnCancel.setOpaque(true);
        btnCancel.setBorderPainted(false);   //NEEDED ON MAC

        this.getContentPane().setLayout(null);
        this.getContentPane().add(txtIssueId);
        this.getContentPane().add(lblIssueId);
        this.getContentPane().add(lblIssueDate);
        this.getContentPane().add(txtIssueDate);
        this.getContentPane().add(lblStudentId);
        this.getContentPane().add(txtStudentId);
        this.getContentPane().add(txtBookId);
        this.getContentPane().add(lblBookId);
        this.getContentPane().add(title);
        this.getContentPane().add(btnIssue);
        this.getContentPane().add(btnCancel);

        IssueBussinessHandler issueBussinessHandler = new IssueBussinessHandler(this);
        btnIssue.addActionListener(issueBussinessHandler);
        btnCancel.addActionListener(issueBussinessHandler);

        JFrame.setDefaultLookAndFeelDecorated(true);
        this.setSize(500,450);
        this.show();

        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
    }

    public JLabel getLblBookId() {
        return lblBookId;
    }

    public void setLblBookId(JLabel lblBookId) {
        this.lblBookId = lblBookId;
    }

    public JButton getBtnIssue() {
        return btnIssue;
    }

    public void setBtnIssue(JButton btnIssue) {
        this.btnIssue = btnIssue;
    }

    public JButton getBtnCancel() {
        return btnCancel;
    }

    public void setBtnCancel(JButton btnCancel) {
        this.btnCancel = btnCancel;
    }

    public JTextField getTxtBookId() {
        return txtBookId;
    }

    public void setTxtBookId(JTextField txtBookId) {
        this.txtBookId = txtBookId;
    }

    public  static void main(String[] args){
        IssueBooksUi issueBooksUi = new IssueBooksUi();

    }

    public JLabel getLblStudentId() {
        return lblStudentId;
    }

    public void setLblStudentId(JLabel lblStudentId) {
        this.lblStudentId = lblStudentId;
    }

    public JLabel getLblIssueDate() {
        return lblIssueDate;
    }

    public void setLblIssueDate(JLabel lblIssueDate) {
        this.lblIssueDate = lblIssueDate;
    }

    public JTextField getTxtStudentId() {
        return txtStudentId;
    }

    public void setTxtStudentId(JTextField txtStudentId) {
        this.txtStudentId = txtStudentId;
    }

    public JTextField getTxtIssueDate() {
        return txtIssueDate;
    }

    public void setTxtIssueDate(JTextField txtIssueDate) {
        this.txtIssueDate = txtIssueDate;
    }

    public void setTitle(JLabel title) {
        this.title = title;
    }

    public JLabel getLblIssueId() {
        return lblIssueId;
    }

    public void setLblIssueId(JLabel lblIssueId) {
        this.lblIssueId = lblIssueId;
    }

    public JTextField getTxtIssueId() {
        return txtIssueId;
    }

    public void setTxtIssueId(JTextField txtIssueId) {
        this.txtIssueId = txtIssueId;
    }
}






