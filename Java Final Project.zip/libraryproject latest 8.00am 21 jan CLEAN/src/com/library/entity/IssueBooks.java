package com.library.entity;


public class IssueBooks {
    private String StudentId;
    private String IssueDate;
    private String IssuedTill;
    private String BookId;
    private String IssueId;

    public String getIssueId() {
        return IssueId;
    }

    public void setIssueId(String issueId) {
        IssueId = issueId;
    }

    public IssueBooks(String studentId, String issueDate, String bookId, String issueId) {
        StudentId = studentId;
        IssueDate = issueDate;
        BookId = bookId;
        IssueId = issueId;
    }

    public IssueBooks(){

    }

    public String getBookId() {
        return BookId;
    }

    public void setBookId(String bookId) {
        BookId = bookId;
    }

    public String getStudentId() {
        return StudentId;
    }

    public void setStudentId(String studentId) {
        StudentId = studentId;
    }

    public String getIssueDate() {
        return IssueDate;
    }

    @Override
    public String toString() {
        return "IssueBooks{" +
                "StudentId='" + StudentId + '\'' +
                ", IssueDate='" + IssueDate + '\'' +
                ", IssuedTill='" + IssuedTill + '\'' +
                ", BookId='" + BookId + '\'' +
                ", IssueId='" + IssueId + '\'' +
                '}';
    }

    public void setIssueDate(String issueDate) {
        IssueDate = issueDate;
    }

    public String getIssuedTill() {
        return IssuedTill;
    }

    public void setIssuedTill(String issuedTill) {
        IssuedTill = issuedTill;
    }


}
